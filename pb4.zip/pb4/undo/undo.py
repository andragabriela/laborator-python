def copiaza(a,u):
    a.clear()
    for el in u:
        a.append(el)
    return a