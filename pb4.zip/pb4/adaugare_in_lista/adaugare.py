from pb4.validare.validtransaction import valideaza_transaction
from pb4.domain.transaction import tranzactie, egale_transactions
def adauga_tranzactie_in_lista(l,transaction):
    #functie care adauga o tranzactie in lista de tranzactii l
    #input: l lista de tranzactii, transaction o tranzactie
    #output:-, daca adaugarea are loc
    #raises: Exception cu textul
    # "tranzactie existenta!\n" daca exista deja tranzactia cu acelasi id (2)
    for _transaction in l:
        if egale_transactions(_transaction, transaction):
            raise Exception("tranzactie existenta!\n")
    l.append(transaction)
def srv_adauga_in_lista(l, id, ziua, suma, tip):
    # functie care creeaza o tranzactie pe baza unui id, unei zi, unei sume, unui tip si o adauga in lista
    # input: l- lista de tranzactii unice
    #        id- id-ul unei tranzactii
    #        ziua- ziua tranzactieri
    #        suma- suma retrasa/adaugata
    #       tip- iesire/ intrare
    #output-, daca adauga cu succes
    #raises exception cu textul (1) si (2)
    transaction=tranzactie(id, ziua, suma, tip)
    valideaza_transaction(transaction)
    adauga_tranzactie_in_lista(l, transaction)
def ui_adauga_transaction(l):
    """
    functie care dupa citirea unor date le verifica sa fie corecte pentru tipul fiecareia
    """
    try:
        id=int(input("id transaction:"))
    except ValueError:
        print("valoare numerica invalida pentru id")
        return
    try:
        ziua=int(input("ziua transaction:"))
    except ValueError:
        print("valoare numerica invalida pentru ziua")
        return
    try:
        suma=float(input("suma transaction:"))
    except ValueError:
        print("valoare numerica invalida pentru suma")
        return
    try:
        tip=input("tip transaction:")
    except ValueError:
        print("valoare invalida pentru tip")
        return
    srv_adauga_in_lista(l, id, ziua, suma, tip)
