from pb4.domain.transaction import tranzactie, get_id, get_ziua, get_tip, get_suma, egale_transactions
from pb4.validare.validtransaction import valideaza_transaction
from pb4.adaugare_in_lista.adaugare import srv_adauga_in_lista, adauga_tranzactie_in_lista
from pb4.delete.delete_transaction import delete_type, delete_day, delete_perioada
from pb4.eliminare.elimin_transaction import *
from pb4.rapoarte.rapoarte import *
def test_elimin_transaction_type():
    l1 = []
    a1 = tranzactie('15', '25', '250', 'intrare')
    adauga_tranzactie_in_lista(l1, a1)
    a2 = tranzactie('1', '24', '350', 'iesire')
    adauga_tranzactie_in_lista(l1, a2)
    a3 = tranzactie('5', '15', '50', 'intrare')
    adauga_tranzactie_in_lista(l1, a3)
    l2 = elimin_transaction_type(l1, 'intrare')
    assert len(l2) == 1
def test_elimin_transaction_suma_type():
    l1 = []
    a1 = tranzactie('15', '25', '250', 'intrare')
    adauga_tranzactie_in_lista(l1, a1)
    a2 = tranzactie('1', '24', '350', 'iesire')
    adauga_tranzactie_in_lista(l1, a2)
    a3 = tranzactie('5', '15', '50', 'intrare')
    adauga_tranzactie_in_lista(l1, a3)
    l2 = elimin_transaction_suma_type(l1, '100', 'intrare')
    assert len(l2) == 2
def test_suma_raport():
    l1 = []
    a1 = tranzactie('5', '25', '1000', 'intrare')
    adauga_tranzactie_in_lista(l1, a1)
    a2 = tranzactie('1', '24', '300', 'iesire')
    adauga_tranzactie_in_lista(l1, a2)
    a3 = tranzactie('3', '30', '20', 'intrare')
    adauga_tranzactie_in_lista(l1, a3)
    s = suma_raport(l1, 'intrare')
    assert s == 1020
def test_sold_data():
    l1 = []
    a1 = tranzactie('5', '15', '1000', 'intrare')
    adauga_tranzactie_in_lista(l1, a1)
    a2 = tranzactie('1', '15', '300', 'iesire')
    adauga_tranzactie_in_lista(l1, a2)
    a3 = tranzactie('3', '30', '20', 'intrare')
    adauga_tranzactie_in_lista(l1, a3)
    sold = sold_data(l1, '15')
    assert sold == 700
def test_order_suma():
    l1 = []
    a1 = tranzactie('5', '15', '1000', 'intrare')
    adauga_tranzactie_in_lista(l1, a1)
    a2 = tranzactie('1', '15', '300', 'iesire')
    adauga_tranzactie_in_lista(l1, a2)
    a3 = tranzactie('3', '30', '20', 'intrare')
    adauga_tranzactie_in_lista(l1, a3)
    l2 =  order_suma(l1, 'intrare')
    assert len(l2)==2
def test_tranzactie():
    id = 2
    ziua = 15
    suma = 200
    tip = "iesire"
    transaction = tranzactie(id, ziua, suma, tip)
    assert (get_id(transaction) == id)
    assert (get_ziua(transaction) == ziua)
    assert (get_tip(transaction) == tip)
    assert (abs(get_suma(transaction) - suma) < 0.0001)
def test_valideaza_transaction():
    transaction=tranzactie(2,15,200,"iesire")
    valideaza_transaction(transaction)
    invalid_id = tranzactie(-2, 10, 150, "iesire")
    try:
        valideaza_transaction(invalid_id)
        assert (False)
    except Exception as ex:
        assert(str(ex)=="id invalid!\n")
    invalid_transaction_ziua=tranzactie(2,-20,200,"iesire")
    try:
        valideaza_transaction(invalid_transaction_ziua)
        assert(False)
    except Exception as ex:
        assert(str(ex)=="ziua invalida!\n")
    invalid_suma=tranzactie(2,10,-12,"intrare")
    try:
        valideaza_transaction(invalid_suma)
        assert(False)
    except Exception as ex:
        assert(str(ex) == "suma invalida!\n")
    invalid_tip = tranzactie(2, 10, 150, "")
    try:
        valideaza_transaction(invalid_tip)
        assert(False)
    except Exception as ex:
        assert(str(ex)=="tipul invalid!\n")
    invalid_tip_suma = tranzactie(2, 10, -20, "")
    try:
        valideaza_transaction(invalid_tip_suma)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "tipul invalid!\nsuma invalida!\n")
    invalid_tip_ziua = tranzactie(2, -2, 150, "")
    try:
        valideaza_transaction(invalid_tip_ziua)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "tipul invalid!\nziua invalida!\n")
    invalid_suma_ziua = tranzactie(2,-10, -150, "iesire")
    try:
        valideaza_transaction(invalid_suma_ziua)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "ziua invalida!\nsuma invalida!\n")
    invalid_suma_ziua_tip = tranzactie(2, -10, -150, "")
    try:
        valideaza_transaction(invalid_suma_ziua_tip)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "tipul invalid!\nziua invalida!\nsuma invalida!\n")
    invalid_suma_ziua_tip_id = tranzactie(-2, -10, -150, "")
    try:
        valideaza_transaction(invalid_suma_ziua_tip_id)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "id invalid!\ntipul invalid!\nziua invalida!\nsuma invalida!\n")
    invalid_suma_ziua_id = tranzactie(-2, -10, -150, "iesire")
    try:
        valideaza_transaction(invalid_suma_ziua_id)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "id invalid!\nziua invalida!\nsuma invalida!\n")
    invalid_suma_tip_id = tranzactie(-2, 10, -150, "")
    try:
        valideaza_transaction(invalid_suma_tip_id)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "id invalid!\ntipul invalid!\nsuma invalida!\n")
    invalid_suma_id = tranzactie(-2, 10, -150, "iesire")
    try:
        valideaza_transaction(invalid_suma_id)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "id invalid!\nsuma invalida!\n")
    invalid_ziua_id = tranzactie(-2, -10, 150, "iesire")
    try:
        valideaza_transaction(invalid_ziua_id)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "id invalid!\nziua invalida!\n")
    invalid_tip_id = tranzactie(-2, 10, 150, "")
    try:
        valideaza_transaction(invalid_tip_id)
        assert (False)
    except Exception as ex:
        assert (str(ex) == "id invalid!\ntipul invalid!\n")
def test_delete_type():
    l1 = []
    a1 = tranzactie('15', '25', '250', 'intrare')
    adauga_tranzactie_in_lista(l1, a1)
    a2 = tranzactie('1', '24', '350', 'iesire')
    adauga_tranzactie_in_lista(l1, a2)
    a3 = tranzactie('5', '15', '50', 'intrare')
    adauga_tranzactie_in_lista(l1, a3)
    delete_type(l1, 'intrare')
    assert len(l1) == 1
def test_delete_day():
    l1=[]
    a1=tranzactie('15','25','250','intrare')
    adauga_tranzactie_in_lista(l1, a1)
    a2 = tranzactie('1', '24', '350', 'iesire')
    adauga_tranzactie_in_lista(l1, a2)
    a3 = tranzactie('5', '24', '50', 'intrare')
    adauga_tranzactie_in_lista(l1, a3)
    delete_day(l1, '24')
    assert(len(l1) == 1)
def test_delete_perioada():
    l1 = []
    a1 = tranzactie('15', '25', '250', 'intrare')
    adauga_tranzactie_in_lista(l1, a1)
    a2 = tranzactie('1', '24', '350', 'iesire')
    adauga_tranzactie_in_lista(l1, a2)
    a3 = tranzactie('5', '15', '50', 'intrare')
    adauga_tranzactie_in_lista(l1, a3)
    delete_perioada(l1, '21', '26')
    assert len(l1) == 1

def test_srv_adauga_in_lista():
    l=[]
    srv_adauga_in_lista(l,2,13,250,"iesire")
    assert(len(l)==1)
    try:
        srv_adauga_in_lista(l,2,14,200,"intrare")
        assert(False)
    except Exception as ex:
        assert(str(ex)=="tranzactie existenta!\n")
    """try:
        srv_adauga_in_lista(l,21,140,2000,"")
        assert(False)
    except Exception as ex:
        assert(str(ex)=="tipul invalid!\n")"""
def test_adauga_tranzactie_in_lista():
    l=[]
    transaction=tranzactie(3,10,600,"intrare")
    adauga_tranzactie_in_lista(l,transaction)
    assert(len(l)==1)
    assert(get_tip(transaction)==get_tip(l[0]))
    assert(get_ziua(transaction)==get_ziua(l[0]))
    assert(abs(get_suma(transaction)-get_suma(l[0]))<0.0001)
    assert(get_id(transaction)==get_id(l[0]))
    try:
        adauga_tranzactie_in_lista(l,transaction)
        assert(False)
    except Exception as ex:
        assert(str(ex)=="tranzactie existenta!\n")

def run_teste():
    test_tranzactie()
    test_valideaza_transaction()
    test_adauga_tranzactie_in_lista()
    test_srv_adauga_in_lista()
    test_delete_day()
    test_delete_type()
    test_delete_perioada()