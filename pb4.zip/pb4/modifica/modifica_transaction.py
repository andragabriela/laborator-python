from pb4.domain.transaction import tranzactie
from pb4.validare.validtransaction import valideaza_transaction
from pb4.adaugare_in_lista.adaugare import adauga_tranzactie_in_lista
def srv_adauga_transaction(l,id, ziua, suma, tip):
    """
    functie care creeaza o tranzactie cu valorile introduse, o valideaza, iar apoi o adauga in lista
    functia va afisa erorile corespunzatoare daca datele introduse nu sunt corecte
    input: l - lista
           id int
           ziua - int
           suma - float
           tip - string
    output: -, daca tranzactia este adaugata in lista
    """
    transaction = tranzactie(id, ziua, suma, tip)
    valideaza_transaction(transaction)
    adauga_tranzactie_in_lista(l,transaction)
def srv_modifica_transaction(l,id, ziua, suma, tip,elem):
    """
    functie care creeaza o tranzactie cu valorile introduse, o valideaza, iar apoi modifica valorile elementului
    din lista corespunzator cu valoarea aleasa de utilizator daca datele introduse sunt corecte
    input: l - lista
            id int
           ziua -int
           suma - float
           tip - string
           elem - float
    output: -, daca cheltuiala selectata de utilizator este modificata
    """
    transaction = tranzactie(id, ziua, suma, tip)
    valideaza_transaction(transaction)
    l[elem-1] = transaction
def ui_modifica_transaction(l):
    """
    functia preia pozitia elementului din lista pe care utilizatorul doreste sa o modifice,
    apoi citeste noile valori pe care utilizatorul doreste sa le insereze
    input: l - lista
    output: l - lista,
            id int
            ziua- int
            suma - float
            tip - string
            elem - int
    """
    elem = len(l)+1
    while(elem>(len(l))):
        try:
            elem = int(input("Introduceti numarul tranzactiei pe care doriti sa o modificati:"))
        except ValueError:
            print("Introduceti o valoare intreaga si mai mica decat ultimul element din lista!")
    try:
        id = int(input("id:"))
    except ValueError:
        print("Valoare incorecta!")
    try:
        ziua = int(input("ziua:"))
    except ValueError:
        print("Valoare incorecta!")

    try:
        suma = float(input("suma:"))
    except ValueError:
        print("Valoare incorecta!")

    tip = input("Tip:")
    srv_modifica_transaction(l,id, ziua, suma, tip, elem)