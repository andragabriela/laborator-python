from pb4.domain.transaction import get_suma, get_ziua, get_tip
def cauta_in_lista_suma_mai_mare(l, suma2):
    """
    functie care adauga intr-o lista noua elementele care au suma mai mare decat o suma data
    input: l- lista de tranzactii
           suma2- suma citita
    output: l2-lista noua
    """
    l2=[]
    i=0
    while i<len(l):
        if get_suma(l[i])>suma2:
            l2.append(l[i])
        i=i+1
    return l2
def ui_print_cauta_in_lista_suma_mai_mare(l):
    """
        functie care citeste suma2 si tipareste lista cu datele cerute
        """
    suma2=int(input("citeste suma:"))
    l2=cauta_in_lista_suma_mai_mare(l, suma2)
    print(l2)
def cauta_in_lista_un_tip(l, type2):
    """
        functie care adauga intr-o lista noua elementele care au tipul egal cu un tip dat
        input: l- lista de tranzactii
               type2- tipul citit
        output: l2-lista noua
        """
    l2=[]
    i=0
    while i<len(l):
        if get_tip(l[i]) == type2:
            l2.append(l[i])
        i=i+1
    return l2
def ui_print_cauta_in_lista_un_tip(l):
    """
        functie care citeste type2 si tipareste lista cu datele cerute
        """
    type2=input("citeste tipul:")
    l2=cauta_in_lista_un_tip(l, type2)
    print(l2)
def cauta_day_suma(l, zi2, suma2):
    """
            functie care adauga intr-o lista noua elementele care ziua mai mica decat o zi data si suma mai mare decat o suma data
            input: l- lista de tranzactii
                   zi2- ziua citita
                   suma2- suma citita
            output: l2-lista noua
    """
    l2=[]
    i = 0
    while i < len(l):
        if get_ziua(l[i]) <zi2 and get_suma(l[i])> suma2:
            l2.append(l[i])
        i = i + 1
    return l2
def ui_print_cauta_day_suma(l):
    """
    functie care citeste zi2 si suma2 si tipareste lista cu datele cerute
    """
    zi2=int(input("citeste ziua:"))
    suma2=int(input("citeste suma: "))
    l2=cauta_day_suma(l, zi2, suma2)
    print(l2)