from pb4.domain.transaction import get_ziua, get_tip
def delete_type(l, type):
    """
        Functie care sterge toate tranzactiile de anumit tip data din lista
        input l lista cu datele si tipul citita de la tastatura
        output nimic daca stergerea este corecta
        """
    i=0
    while i<len(l):
        if get_tip(l[i])==type:
            l.pop(i)
        else: i=i+1
def delete_perioada(l, ziua1, ziua2):
    """
            Functie care sterge toate tranzactiile dintr-un interval de timp din lista
            input l lista cu datele si cele doua zile care reprezinta capetele intervalului de la tastatura
            output nimic daca stergerea este corecta
            """
    i = 0
    while i < len(l):
        if get_ziua(l[i]) >= ziua1 and get_ziua(l[i])<=ziua2:
            l.pop(i)
        else:
            i = i + 1
def delete_day(l, ziua):
    """
    Functie care sterge toate tranzactiile dintr-o zi data din lista
    input l lista cu datele si ziua citita de la tastatura
    output nimic daca stergerea este corecta
    """
    i=0
    while i<len(l):
        if get_ziua(l[i])==ziua:
            l.pop(i)
        else: i=i+1