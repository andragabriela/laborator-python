def ui_print_transaction(l):
    """
    functie care printeaza tranzactiile
    """
    for tra in l:
        print(tra)