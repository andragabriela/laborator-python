from pb4.eliminare.elimin_transaction import *
from pb4.print.printare import *
from pb4.modifica.modifica_transaction import *
from pb4.testing.teste import run_teste
from pb4.delete.delete_transaction import *
from pb4.adaugare_in_lista.adaugare import *
from pb4.domain.transaction import *
from pb4.cauta.cauta_in_lista import *
from pb4.rapoarte.rapoarte import *
from pb4.undo.undo import *
def main():
    run_teste()


def run():
    l=[]
    aux = []
    print("\tGestionarea tranzactiilor unui cont bancar\n"
          "add_transaction: Adauga o noua tranzactie\n"
          "print_tranzactii: Printeaza tranzactii\n"
          "delete_day: Sterge toate tranzactiile pentru o anumita zi\n"
          "delete_perioada: Sterge toate tranzactiile dintr-un anumit interval de zile\n"
          "delete_tip: Sterge tranzactiile de un anumit tip\n"
          "print_bigger: Tipareste "
          "tranzactiile mai mari decat o anumita suma\n"
          "print_type: Tipareste toate cheltuielile de un anumit tip\n"
          "print_day_bigger Tipareste tranzactiile de dinaintea unei zile si mai mari decat o suma data\n"
          "update: Modifica o tranzactie\n"
          "elimin_transaction_type: Elimina tranzactiile de un anumit tip\n"
          "elimin_transaction_suma_type:Elimină toate tranzacțiile mai mici decât o sumă dată care au tipul specificat\n"
          "raport_suma:scrie suma elementelor care au tipul egal cu un tip dat\n"
          "sold_data: tipareste  soldul contului la o data specificata\n"
          "order_suma: ordoneaza elementele de un anumit tip din lista dupa suma\n"
          "undo:Reface ultima operatie\n")
    while True:
        cmd=input(">>>")
        if cmd=="exit":
            return
        if cmd=="":
            continue
        if cmd=="add_transaction":
            try:
                aux=copiaza(aux, l)
                ui_adauga_transaction(l)
            except Exception as ex:
                print(ex)
        elif cmd=="print_tranzactii":
            ui_print_transaction(l)
        elif cmd=="delete_day":
            aux = copiaza(aux, l)
            ziua=int(input("citeste zi: "))
            delete_day(l, ziua)
        elif cmd=="delete_perioada":
            aux = copiaza(aux, l)
            ziua1=int(input("citeste ziua1: "))
            ziua2=int(input("citeste ziua2: "))
            delete_perioada(l, ziua1, ziua2)
        elif cmd=="delete_tip":
            aux = copiaza(aux, l)
            type=input("citeste tipul: ")
            delete_type(l, type)
        elif cmd== "print_bigger":
            ui_print_cauta_in_lista_suma_mai_mare(l)
        elif cmd=="print_type":
            ui_print_cauta_in_lista_un_tip(l)
        elif cmd=="print_day_bigger":
            ui_print_cauta_day_suma(l)
        elif cmd=="update":
            aux = copiaza(aux, l)
            ui_modifica_transaction(l)
        elif cmd=="elimin_transaction_type":
            type2 = input("citeste: ")
            ui_afisare(l,type2)
        elif cmd=="elimin_transaction_suma_type":
            suma2=int(input("suma este: "))
            type2=input("citeste: ")
            ui_afisare_2(l, suma2, type2)
        elif cmd=="raport_suma":
            ui_raport_suma(l)
        elif cmd=="sold_data":
            ui_sold_data(l)
        elif cmd=="order_suma":
            ui_order_suma(l)
        elif cmd=="undo":
                if l==aux:
                    print("undo efectuat")
                else:
                    l=copiaza(l,aux)
        else:
            print("comanda invalida!")

def new_interface():
    l=[]
    while True:
        command = input("enter option")
        cmd = command.split(" ")
        if cmd[0]=="adauga":
            try:
                srv_adauga_in_lista(l,int(cmd[1]), int(cmd[2]),float(cmd[3]),cmd[4])
            except Exception as ex:
                print(ex)
        elif cmd[0]=="modifica":
            try:
                srv_modifica_transaction(l, cmd[1], cmd[2], cmd[3],cmd[4], int(cmd[5]))
            except Exception as ex:
                print(ex)
        elif cmd[0]=="print":
            print(l)
        elif cmd[0]=="order":
            if(cmd[1]=="iesire" or cmd[1]=="intrare"):
                order_suma(l, cmd[1])
run()