from pb4.domain.transaction import get_tip, get_suma, get_ziua
from pb4.adaugare_in_lista.adaugare import adauga_tranzactie_in_lista
def suma_raport(l, type2):
    """functie care face suma elementelor care au tipul egal cu un tip dat
    input:l- lista de tranzactii
        type2- tipul citit
     output: s- suma finala """
    s=0
    for i in range(len(l)):
        if get_tip(l[i]) == type2:
            s=s+get_suma(l[i])
    return s
def ui_raport_suma(l):
    """
    functie care citeste tipul si printeaza suma elementelor care au tipul respectiv
    input: l- lista de tranzactii
    output: printarea sumei
    """
    type2=input("citeste: ")
    s=suma_raport(l, type2)
    print(s)
def sold_data(l, data2):
    """functie care returneaza  soldul contului la o data specificata
        input:l- lista de tranzactii
        data2- data citita
     output: sold- sold final """
    sold=0
    for i in range(len(l)):
        if get_ziua(l[i]) == data2:
            if get_tip(l[i])=="iesire":
                sold=sold-get_suma(l[i])
            else :
                sold=sold+get_suma(l[i])
    return sold
def ui_sold_data(l):
    """
        functie care citeste data si printeaza soldul din data respectiva
        input: l- lista de tranzactii
        output: printarea sumei
        """
    data2=int(input("citeste: "))
    sold=sold_data(l, data2)
    print(sold)
def order_suma(l, type2):
    """functie care adauga intr-o lista noua elementele din lista initiala care au tipul egal cu tipul citit
            input:l- lista de tranzactii
            type2- tipul citita
         output: l2 """
    l2=[]
    for i in range(len(l)):
        if get_tip(l[i])==type2:
            adauga_tranzactie_in_lista(l2, l[i])
    return l2
def ui_order_suma(l):
    """
        functie care citeste tipul si printeaza ordoneaza toate tranzactiile de un anumit tip dupa suma
        input: l- lista de tranzactii
        output: printarea sumei
        """
    type2=input("citeste tipul: ")
    l2=order_suma(l, type2)
    l2.sort(key=get_suma)
    print(l2)
