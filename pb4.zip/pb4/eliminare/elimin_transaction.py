from pb4.domain.transaction import get_tip, get_suma
from pb4.adaugare_in_lista.adaugare import adauga_tranzactie_in_lista
def elimin_transaction_type(l, type2):
    """
    functie care elimina tranzactile de un anumit tip prin adaugarea tranzactilor bune intr-o alta lista, astfel lista initiala nu sufera modificari
    input: l- lista tranzactii
           type2- tipul citit de la tastatura
    output: l2- noua lista cu datele corecte
    """
    l2 = []
    i = 0
    while i < len(l):
        if get_tip(l[i]) != type2:
            adauga_tranzactie_in_lista(l2 ,l[i])
        i = i + 1
    return l2
def elimin_transaction_suma_type(l, suma2,type2):
    """
        functie care elimina tranzactile de un anumit tip si cu suma mai mica decat o suma data prin adaugarea tranzactilor bune intr-o alta lista, astfel lista initiala nu sufera modificari
        input: l- lista tranzactii
               type2- tipul citit de la tastatura
               suma2- suma citita de la tastatura
        output: l2- noua lista cu datele corecte
        """
    l2 = []
    i = 0
    while i < len(l):
        if get_tip(l[i]) != type2 and get_suma(l[i])>=suma2:
            adauga_tranzactie_in_lista(l2, l[i])
        i = i + 1
    return l2
def ui_afisare(l, type2):
    """
    functie care apeleaza elimin_transaction_type si printeaza lista cu datele corecte
    """
    l2=elimin_transaction_type(l, type2)
    print(l2)
def ui_afisare_2(l,suma2, type2):
    """
        functie care apeleaza elimin_transaction_suma_type si printeaza lista cu datele corecte
        """
    l2=elimin_transaction_suma_type(l, suma2, type2)
    print(l2)