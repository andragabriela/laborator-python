def tranzactie(id , ziua, suma, tip):
    # functie carecreaza o tranzactie ce are ziua de tip intreg, suma de tip float si tipul de tip caracter, id idul fiecarei tranzactii
    # input: ziua- intreg
    #       suma- float
    #       tip- char
    #       id- intreg
    # output: tranzactie, ziua intreg, suma float, tip caracter
    return {
        "id":id,
        "ziua":ziua,
        "suma":suma,
        "tip":tip
    }
def get_id(transaction):
    # functie care returneaza idul tranzactiei transaction
    # input: transaction-o tranzactie
    # output:rez- idul tranzactiei transaction
    return transaction["id"]
def get_ziua(transaction):
    # functie care returneaza ziua tranzactiei transaction
    # input: transaction-o tranzactie
    # output:rez- ziua tranzactiei transaction
    return transaction["ziua"]
def get_suma(transaction):
    # functie care returneaza suma tranzactiei transaction
    # input: transaction-o tranzactie
    # output:rez- suma tranzactiei transaction
    return transaction["suma"]
def get_tip(transaction):
    # functie care returneaza tipul tranzactiei transaction
    # input: transaction-o tranzactie
    # output:rez- tipul tranzactiei transaction
    return transaction["tip"]
def egale_transactions(transaction0, transaction1):
    #functie care returneaza daca doua variabile sunt egale
    return get_id(transaction0)==get_id(transaction1)