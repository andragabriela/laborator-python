from pb4.domain.transaction import get_id, get_ziua, get_tip, get_suma
def valideaza_transaction(transaction):
    # functie care valideaza daca ziua transactiei este pozitiva, daca suma este intre 0 si 20000, daca tipul e nevid
    # input:transaction- o tranzactie
    # output:-, daca tranzactia e valida
    # raises: exceptions cu textul:(1)
    #       "ziua invalida!\n", daca ziua<=0 sau ziua>31
    #       "suma invalida!\n", daca suma<0 sau suma> 20000
    #       "id invalid!\n", daca id<0
    #       "tipul invalid!\n", daca tipul=""
    err = ""
    if get_id(transaction)<0:
        err += "id invalid!\n"
    if get_tip(transaction)=="":
        err += "tipul invalid!\n"
    if get_ziua(transaction) <=0 or get_ziua(transaction)>31:
        err += "ziua invalida!\n"
    suma = get_suma(transaction)
    if suma <0 or suma >20000:
        err += "suma invalida!\n"
    if len(err) >0:
        raise Exception(err)
